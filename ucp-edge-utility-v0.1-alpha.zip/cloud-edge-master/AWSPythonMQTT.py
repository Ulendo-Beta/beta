'''
/*
 * Copyright 2010-2017 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *  http://aws.amazon.com/apache2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

/* Modified by Deepen Solanki, S2A Lab, University of Michigan for the
 * purpose of Project Ulendo - May 2020
 * Please check necessary dependancies at link below and install them
 * https://docs.aws.amazon.com/greengrass/latest/developerguide/IoT-SDK.html
 * Replace end-point and auth certificates with your own.
 */

 '''

from AWSIoTPythonSDK.MQTTLib import AWSIoTMQTTClient
import logging
import time
import argparse
import json
import serial

AllowedActions = ['both', 'publish', 'subscribe']

#This is the global serial file descriptor to exchange messages with the printer
ser = -1

ser2 = 0

request = 0

#Enhanced python serial readline function found on a github issue
class ReadLine:
    def __init__(self, s):
        self.buf = bytearray()
        self.s = s

    def readline(self):
        i = self.buf.find(b"\n")
        if i >= 0:
            r = self.buf[:i+1]
            self.buf = self.buf[i+1:]
            return r
        while True:
            i = max(1, min(2048, self.s.in_waiting))
            data = self.s.read(i)
            i = data.find(b"\n")
            if i >= 0:
                r = self.buf + data[:i+1]
                self.buf[0:] = data[i+1:]
                return r
            else:
                self.buf.extend(data)

#Custom MQTT message callback. Defined by AWS.
#This function is also triggered if a serial message comes in
#We have a JSON field called "type" = 1331 for GCode and 1441 for stepper commands
#for messages coming from the cloud
#If type matches any of these values, only then we send the message to the printer
def customCallback(client, userdata, message):
    global ser
    global ser2
    global request
    request = 0
    x = json.loads(message.payload.decode('utf-8'))
    #xda = x["data"].encode()
    #x = json.loads(message.payload)
    if x["type"]==1331:
        print("Data from cloud",x["data"])
        print("Length", len(x["data"]))
        print("Type", x["type"])
        if ser!= -1:
            ser.write(x["data"].encode())
    if x["type"]==1441:
        print("Data from cloud",x["data"])
        print("Length", len(x["data"]))
        print("Type", x["type"])
        if ser!= -1:
            ser.write(x["data"].encode())




#This function sets up serial communication between RPi and 3D Printer
#It will first try ACM0, if succesful, return
#Next, it will try ACM1, if succesful, return
#If none of the two are succcesful, printer isn't connected or serial connection is faulty
def setupUART():
    try:
        ser = serial.Serial('/dev/ttyACM0', 250000)
        if ser.is_open:
            print("Serial port opened on ACM0. Initializing...")
            time.sleep(10)
            print("Initialization complete")
            return ser
    except:
        print("Now trying ACM1")

    ser = serial.Serial('/dev/ttyACM1', 250000)
    if ser.is_open:
        print("Serial port opened on ACM1. Initializing...")
        time.sleep(10)
        print("Initialization complete")
        return ser

    print("Could not open Serial Port on ACM0 or ACM1. Please check if printer is connected")
    return -1

#AWS connection specific settings.
host = "a7qf19n78wi65-ats.iot.us-east-2.amazonaws.com"
rootCAPath = "/home/pi/certs/rootCA.crt"
certificatePath = "/home/pi/certs/AWSUcert.pem"
privateKeyPath = "/home/pi/certs/AWSUprivkey.pem"
port = 8883
useWebsocket = False
clientId = "RaspberryPi"
topic = "sdkTest/sub"
mode = "both"


def main():

    # Configure logging
    logger = logging.getLogger("AWSIoTPythonSDK.core")
    logger.setLevel(logging.DEBUG)
    streamHandler = logging.StreamHandler()
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    streamHandler.setFormatter(formatter)
    logger.addHandler(streamHandler)

# Init AWSIoTMQTTClient
    myAWSIoTMQTTClient = None
    if useWebsocket:
        myAWSIoTMQTTClient = AWSIoTMQTTClient(clientId, useWebsocket=True)
        myAWSIoTMQTTClient.configureEndpoint(host, port)
        myAWSIoTMQTTClient.configureCredentials(rootCAPath)
    else:
        myAWSIoTMQTTClient = AWSIoTMQTTClient(clientId)
        myAWSIoTMQTTClient.configureEndpoint(host, port)
        myAWSIoTMQTTClient.configureCredentials(rootCAPath, privateKeyPath, certificatePath)

    # AWSIoTMQTTClient connection configuration
    myAWSIoTMQTTClient.configureAutoReconnectBackoffTime(1, 32, 20)
    myAWSIoTMQTTClient.configureOfflinePublishQueueing(-1)  # Infinite offline Publish queueing
    myAWSIoTMQTTClient.configureDrainingFrequency(2)  # Draining: 2 Hz
    myAWSIoTMQTTClient.configureConnectDisconnectTimeout(10)  # 10 sec
    myAWSIoTMQTTClient.configureMQTTOperationTimeout(5)  # 5 sec

    # Connect and subscribe to AWS IoT
    myAWSIoTMQTTClient.connect()
    if mode == 'both' or mode == 'subscribe':
        myAWSIoTMQTTClient.subscribe(topic, 1, customCallback)
    time.sleep(2)

    global ser
    global ser2
    global request
    ser = setupUART()
    ser2 = ReadLine(ser)

    if ser!=-1:
        while True:
            if(ser.in_waiting):
                y = ser2.readline()
                print("Serial\n",y.decode("utf-8"))
                if "ok" in y.decode("utf-8"):
                    message = {}
                    message['type'] = 6
                    message['data'] = "ok to send"
                    messageJson = json.dumps(message)
                    myAWSIoTMQTTClient.publish(topic, messageJson, 0)
                else:
                    message = {}
                    message['type'] = 5
                    message['data'] = y.decode("utf-8")
                    messageJson = json.dumps(message)
                    myAWSIoTMQTTClient.publish(topic, messageJson, 0)

    else:
        print("Serial fail\n")


if __name__ == "__main__":
    main()